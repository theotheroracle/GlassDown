package com.sinneida.glass_down2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
