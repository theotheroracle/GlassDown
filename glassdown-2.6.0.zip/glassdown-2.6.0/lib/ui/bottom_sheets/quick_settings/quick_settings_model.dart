import 'package:stacked/stacked.dart';

class QuickSettingsModel extends ReactiveViewModel {}
