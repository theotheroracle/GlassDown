import 'dart:io';

import 'package:async/async.dart';
import 'package:device_apps/device_apps.dart';
import 'package:dio/dio.dart';
import 'package:flutter_logs/flutter_logs.dart';
import 'package:glass_down_v2/app/app.dialogs.dart';
import 'package:glass_down_v2/app/app.locator.dart';
import 'package:glass_down_v2/app/app.snackbar.dart';
import 'package:glass_down_v2/models/app_info.dart';
import 'package:glass_down_v2/services/scraper_service.dart';
import 'package:glass_down_v2/services/settings_service.dart';
import 'package:glass_down_v2/ui/views/apps/apps_view.dart';
import 'package:glass_down_v2/util/function_name.dart';
import 'package:open_filex/open_filex.dart';
import 'package:shizuku_apk_installer/shizuku_apk_installer.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

class DownloadStatusViewModel extends ReactiveViewModel {
  final _scraper = locator<ScraperService>();
  final _nav = locator<NavigationService>();
  final _token = CancelToken();
  final _snackbar = locator<SnackbarService>();
  final _dialog = locator<DialogService>();
  final _settings = locator<SettingsService>();

  CancelableOperation<bool>? operation;

  final revancedPackageName = 'app.revanced.manager.flutter';
  final rvxPackageName = 'app.rvx.manager.flutter';
  final saiPackageName = 'com.aefyr.sai';

  bool _canPop = false;
  bool get canPop {
    if (operation != null && operation!.isCompleted) {
      return true;
    }
    return _canPop;
  }

  bool _installing = false;
  bool get installing => _installing;

  Status get pageStatus => _scraper.pageStatus;
  Status get linkStatus => _scraper.linkStatus;
  Status get apkStatus => _scraper.apkStatus;
  double? get downloadProgress => _scraper.downloadProgress;
  StatusWithUri get saveStatus => _scraper.saveStatus;
  bool get success => operation?.isCompleted ?? false;

  bool _revancedExists = false;
  bool get revancedExists => _revancedExists;

  bool _rvxExists = false;
  bool get rvxExists => _rvxExists;

  bool _saiExists = false;
  bool get saiExists => _saiExists;

  bool _installStatus = false;
  bool get installStatus => _installStatus;

  Future<void> canInstallPackages() async {
    try {
      _installStatus = await _settings.installGranted();
      rebuildUi();
    } catch (e) {
      _snackbar.showCustomSnackBar(
        message: "Cannot check install packages permission",
        variant: SnackbarType.info,
      );
    }
  }

  void returnToAppList() {
    cancel();
    deleteAfterInstall();
    returnTo(home: true);
  }

  Future<void> cancel() async {
    try {
      await operation?.cancel();
      _canPop = true;
    } catch (e) {
      setError(e);
    }
  }

  Future<void> returnTo({bool home = false}) async {
    if (home) {
      _nav.clearStackAndShowView(const AppsView());
    } else {
      _nav.previousRoute;
    }
    _scraper.clearStatuses();
  }

  Future<void> runDownload(AppInfo app) async {
    try {
      operation = CancelableOperation<bool>.fromFuture(
        _scraper.getSelectedApk(app, _token),
        onCancel: () {
          _token.cancel();
          showSnackbar('Download canceled');
        },
      );
    } catch (e) {
      setError(e);
    }
  }

  Future<void> openApk() async {
    try {
      final shizukuAllowed = _settings.shizuku;
      bool shizukuAvailable = false;
      if (shizukuAllowed) {
        shizukuAvailable = await _settings.shizukuAvailable();
      }
      final isBundle = saveStatus.$2!.split('.').last == 'apkm';
      if (isBundle) {
        if (shizukuAvailable) {
          _installing = true;
          rebuildUi();
          await Future.delayed(const Duration(seconds: 4));
          _installing = false;
          rebuildUi();
          return;
        }
        if (_saiExists) {
          await DeviceApps.openApp(saiPackageName);
        } else {
          _dialog.showCustomDialog<void, void>(
            variant: DialogType.bundledApkInfo,
          );
        }
      } else {
        if (shizukuAvailable) {
          _installing = true;
          rebuildUi();
          await ShizukuApkInstaller.installAPK(
            saveStatus.$3.toString(),
            'com.sinneida.glassdown2',
          );
          _installing = false;
          rebuildUi();
          return;
        }
        OpenFilex.open(saveStatus.$2);
      }
    } catch (e) {
      showSnackbar('Cannot open downloaded APK');
      _installing = false;
      FlutterLogs.logError(
        runtimeType.toString(),
        getFunctionName(),
        e.toString(),
      );
    } finally {
      rebuildUi();
    }
  }

  void deleteAfterInstall() {
    try {
      if (_settings.deleteAfterInstall && saveStatus.$2 != null) {
        final downloadedApk = File(saveStatus.$2!);
        downloadedApk.deleteSync();
        final apkName = saveStatus.$2?.split('/').last;
        final message = 'Deleted ${apkName ?? 'downloaded APK'} file';
        FlutterLogs.logInfo(
          runtimeType.toString(),
          getFunctionName(),
          message,
        );
        showSnackbar(message);
      }
    } catch (e) {
      showSnackbar(
        e is PathNotFoundException
            ? 'APK already deleted'
            : 'Cannot delete APK',
      );
      FlutterLogs.logError(
        runtimeType.toString(),
        getFunctionName(),
        e.toString(),
      );
    } finally {
      rebuildUi();
    }
  }

  Future<void> checkForRevancedApp() async {
    try {
      _revancedExists = await DeviceApps.isAppInstalled(revancedPackageName);
      rebuildUi();
    } catch (e) {
      showSnackbar('Cannot check if Revanced App exists on device');
    }
  }

  String getManagerName() {
    final name = _settings.patchesSource;
    switch (name) {
      case 'revanced':
        return 'Revanced';
      case 'revanced_extended':
        return 'RVX';
      default:
        return 'Revanced';
    }
  }

  Future<void> checkForRvxApp() async {
    try {
      _rvxExists = await DeviceApps.isAppInstalled(rvxPackageName);
      rebuildUi();
    } catch (e) {
      showSnackbar('Cannot check if RVX Manager exists on device');
    }
  }

  Future<void> checkForSai() async {
    try {
      _saiExists = await DeviceApps.isAppInstalled(saiPackageName);
      rebuildUi();
    } catch (e) {
      showSnackbar('Cannot check if Split APK Installer exists on device');
    }
  }

  Future<void> openRevancedOrRvx() async {
    try {
      final name = _settings.patchesSource;
      String packageName;
      switch (name) {
        case 'revanced':
          packageName = revancedPackageName;
          break;
        case 'revanced_extended':
          packageName = rvxPackageName;
          break;
        default:
          packageName = revancedPackageName;
      }
      await DeviceApps.openApp(packageName);
    } catch (e) {
      showSnackbar('Cannot launch Revanced App');
    }
  }

  Future<void> openSai() async {
    try {
      await DeviceApps.openApp(saiPackageName);
    } catch (e) {
      showSnackbar('Cannot launch Revanced App');
    }
  }

  void showSnackbar(String msg) {
    _snackbar.showCustomSnackBar(
      variant: SnackbarType.info,
      message: msg,
    );
  }

  @override
  List<ListenableServiceMixin> get listenableServices => [_scraper];
}
