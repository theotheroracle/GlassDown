import 'package:stacked/stacked.dart';

class StatusCardModel extends BaseViewModel {}
