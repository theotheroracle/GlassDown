import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import 'dev_info_dialog_model.dart';

class DevInfoDialog extends StackedView<DevInfoDialogModel> {
  final DialogRequest request;
  final Function(DialogResponse) completer;

  const DevInfoDialog({
    super.key,
    required this.request,
    required this.completer,
  });

  @override
  Widget builder(
    BuildContext context,
    DevInfoDialogModel viewModel,
    Widget? child,
  ) {
    return AlertDialog(
      title: Text(viewModel.title),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(viewModel.description),
        ],
      ),
      actions: [
        FilledButton(
          onPressed: () {
            completer(
              DialogResponse<void>(confirmed: true),
            );
          },
          child: const Text('OK'),
        )
      ],
    );
  }

  @override
  DevInfoDialogModel viewModelBuilder(BuildContext context) =>
      DevInfoDialogModel();
}
