import 'package:stacked/stacked.dart';

class DevInfoDialogModel extends BaseViewModel {
  final title = 'Developer version';
  final description =
      """You're using developer version, which may be unstable, contain unfinished features or certain parts of the app can't work at all. Please restrain from using it and download release version from GlassDown Github page.
      
      Developer version are released as pre-release by GitHub actions and serves me (developer) as a snapshot of current development progress, to assess how is the app working. This version is not meant to use in any case besides your curiosity or you simply agree to use bleeding-edge app which can fail you anytime. :)
  """;
}
