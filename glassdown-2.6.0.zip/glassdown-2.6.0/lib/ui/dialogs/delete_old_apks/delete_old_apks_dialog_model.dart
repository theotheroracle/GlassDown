import 'package:stacked/stacked.dart';

class DeleteOldApksDialogModel extends BaseViewModel {
  final message =
      "This will remove all previously downloaded versions of this app.";
}
