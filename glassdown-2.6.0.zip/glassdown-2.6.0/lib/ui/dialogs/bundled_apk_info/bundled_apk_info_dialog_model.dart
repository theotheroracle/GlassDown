import 'package:stacked/stacked.dart';

class BundledApkInfoDialogModel extends BaseViewModel {
  final message =
      "You're trying to open APK bundle. Android cannot install it by itself, so you need to have Split APK Installer (SAI) installed on your device to open APK";
}
