import 'package:glass_down_v2/models/errors/app_error.dart';

final class UpdateError extends AppError {
  UpdateError(super.message, [super.reason]);
}
