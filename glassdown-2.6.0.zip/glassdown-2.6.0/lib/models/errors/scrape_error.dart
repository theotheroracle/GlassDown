import 'app_error.dart';

final class ScrapeError extends AppError {
  ScrapeError(super.message, [super.reason]);
}
